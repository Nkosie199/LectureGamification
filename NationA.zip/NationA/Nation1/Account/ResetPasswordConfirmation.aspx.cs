﻿using System.Web.UI;

namespace Nation1.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}